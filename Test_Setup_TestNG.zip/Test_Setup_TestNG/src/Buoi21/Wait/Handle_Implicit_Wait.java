package Buoi21.Wait;

public class Handle_Implicit_Wait {

}
