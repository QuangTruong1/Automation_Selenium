package Buoi15.second_package;

import org.testng.annotations.Test;

public class second_class {
	@Test
	public void first_method() {
		System.out.println("2.2.1");
	}

	@Test
	public void second_method() {
		System.out.println("2.2.2");
	}

}
