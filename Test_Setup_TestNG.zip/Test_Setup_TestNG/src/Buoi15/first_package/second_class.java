package Buoi15.first_package;

import org.testng.annotations.Test;

public class second_class {
	@Test
	public void first_method() {
		System.out.println("1.2.1");
	}

	@Test
	public void second_method() {
		System.out.println("1.2.2");
	}

}
