package Buoi15.third_package;

import org.testng.annotations.Test;

public class second_class {
	@Test
	public void first_method() {
		System.out.println("3.2.1");
	}

	@Test
	public void second_method() {
		System.out.println("3.2.2");
	}

}
